<!DOCTYPE html>
	<html dir="rtl" lang="ar">
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title>دخول &rsaquo; الجمعيه التعاونيه الزراعيه غرب نجران &#8212; ووردبريس</title>
	<meta name='robots' content='max-image-preview:large, noindex, noarchive' />
<link rel='stylesheet' id='dashicons-css' href='https://caawn.org.sa/wp-includes/css/dashicons.min.css?ver=6.8.3' type='text/css' media='all' />
<link rel='stylesheet' id='buttons-rtl-css' href='https://caawn.org.sa/wp-includes/css/buttons-rtl.min.css?ver=6.8.3' type='text/css' media='all' />
<link rel='stylesheet' id='forms-rtl-css' href='https://caawn.org.sa/wp-admin/css/forms-rtl.min.css?ver=6.8.3' type='text/css' media='all' />
<link rel='stylesheet' id='l10n-rtl-css' href='https://caawn.org.sa/wp-admin/css/l10n-rtl.min.css?ver=6.8.3' type='text/css' media='all' />
<link rel='stylesheet' id='login-rtl-css' href='https://caawn.org.sa/wp-admin/css/login-rtl.min.css?ver=6.8.3' type='text/css' media='all' />
<link rel='stylesheet' id='c4wp-login-style-css' href='https://caawn.org.sa/wp-content/plugins/advanced-nocaptcha-recaptcha/assets/css/style.css?ver=7.6.0' type='text/css' media='all' />
	<meta name='referrer' content='strict-origin-when-cross-origin' />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<link rel="icon" href="https://caawn.org.sa/wp-content/uploads/2025/09/cropped-512-32x32.jpg" sizes="32x32" />
<link rel="icon" href="https://caawn.org.sa/wp-content/uploads/2025/09/cropped-512-192x192.jpg" sizes="192x192" />
<link rel="apple-touch-icon" href="https://caawn.org.sa/wp-content/uploads/2025/09/cropped-512-180x180.jpg" />
<meta name="msapplication-TileImage" content="https://caawn.org.sa/wp-content/uploads/2025/09/cropped-512-270x270.jpg" />
	</head>
	<body class="login no-js login-action-login wp-core-ui rtl  locale-ar">
	<script type="text/javascript">
/* <![CDATA[ */
document.body.className = document.body.className.replace('no-js','js');
/* ]]> */
</script>

				<h1 class="screen-reader-text">دخول</h1>
			<div id="login">
		<h1 role="presentation" class="wp-login-logo"><a href="https://ar.wordpress.org/">يعمل بواسطة ووردبريس</a></h1>
	
		<form name="loginform" id="loginform" action="https://caawn.org.sa/wp-login.php" method="post">
			<p>
				<label for="user_login">اسم المستخدم أو البريد الإلكتروني</label>
				<input type="text" name="log" id="user_login" class="input" value="" size="20" autocapitalize="off" autocomplete="username" required="required" />
			</p>

			<div class="user-pass-wrap">
				<label for="user_pass">كلمة المرور</label>
				<div class="wp-pwd">
					<input type="password" name="pwd" id="user_pass" class="input password-input" value="" size="20" autocomplete="current-password" spellcheck="false" required="required" />
					<button type="button" class="button button-secondary wp-hide-pw hide-if-no-js" data-toggle="0" aria-label="عرض كلمة المرور">
						<span class="dashicons dashicons-visibility" aria-hidden="true"></span>
					</button>
				</div>
			</div>
			<!-- CAPTCHA added with CAPTCHA 4WP plugin. More information: https://captcha4wp.com --><div class="c4wp_captcha_field" style="margin-bottom: 10px" data-nonce="e34621ff99" data-c4wp-use-ajax="true" data-c4wp-v2-site-key=""><div id="c4wp_captcha_field_1" class="c4wp_captcha_field_div"></div></div><!-- / CAPTCHA by CAPTCHA 4WP plugin -->			<p class="forgetmenot"><input name="rememberme" type="checkbox" id="rememberme" value="forever"  /> <label for="rememberme">تذكرني</label></p>
			<p class="submit">
				<input type="submit" name="wp-submit" id="wp-submit" class="button button-primary button-large" value="دخول" />
									<input type="hidden" name="redirect_to" value="https://caawn.org.sa/wp-admin/" />
									<input type="hidden" name="testcookie" value="1" />
			</p>
		</form>

					<p id="nav">
				<a class="wp-login-lost-password" href="https://caawn.org.sa/wp-login.php?action=lostpassword">هل فقدت كلمة مرورك؟</a>			</p>
			<script type="text/javascript">
/* <![CDATA[ */
function wp_attempt_focus() {setTimeout( function() {try {d = document.getElementById( "user_login" );d.focus(); d.select();} catch( er ) {}}, 200);}
wp_attempt_focus();
if ( typeof wpOnload === 'function' ) { wpOnload() }
/* ]]> */
</script>
		<p id="backtoblog">
			<a href="https://caawn.org.sa/">&rarr; الانتقال إلى الجمعيه التعاونيه الزراعيه غرب نجران</a>		</p>
			</div>
				<div class="language-switcher">
				<form id="language-switcher" method="get">

					<label for="language-switcher-locales">
						<span class="dashicons dashicons-translation" aria-hidden="true"></span>
						<span class="screen-reader-text">
							اللغة						</span>
					</label>

					<select name="wp_lang" id="language-switcher-locales"><option value="en_US" lang="en" data-installed="1">English (United States)</option>
<option value="ar" lang="ar" selected='selected' data-installed="1">العربية</option></select>
					
					
					
						<input type="submit" class="button" value="تغيير">

					</form>
				</div>
			
	<script type="text/javascript" src="https://caawn.org.sa/wp-includes/js/clipboard.min.js?ver=2.0.11" id="clipboard-js"></script>
<script type="text/javascript" src="https://caawn.org.sa/wp-includes/js/jquery/jquery.min.js?ver=3.7.1" id="jquery-core-js"></script>
<script type="text/javascript" src="https://caawn.org.sa/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.4.1" id="jquery-migrate-js"></script>
<script type="text/javascript" id="zxcvbn-async-js-extra">
/* <![CDATA[ */
var _zxcvbnSettings = {"src":"https:\/\/caawn.org.sa\/wp-includes\/js\/zxcvbn.min.js"};
/* ]]> */
</script>
<script type="text/javascript" src="https://caawn.org.sa/wp-includes/js/zxcvbn-async.min.js?ver=1.0" id="zxcvbn-async-js"></script>
<script type="text/javascript" src="https://caawn.org.sa/wp-includes/js/dist/hooks.min.js?ver=4d63a3d491d11ffd8ac6" id="wp-hooks-js"></script>
<script type="text/javascript" src="https://caawn.org.sa/wp-includes/js/dist/i18n.min.js?ver=5e580eb46a90c2b997e6" id="wp-i18n-js"></script>
<script type="text/javascript" id="wp-i18n-js-after">
/* <![CDATA[ */
wp.i18n.setLocaleData( { 'text direction\u0004ltr': [ 'rtl' ] } );
/* ]]> */
</script>
<script type="text/javascript" id="password-strength-meter-js-extra">
/* <![CDATA[ */
var pwsL10n = {"unknown":"\u0642\u0648\u0629 \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631 \u063a\u064a\u0631 \u0645\u0639\u0631\u0648\u0641\u0629","short":"\u0636\u0639\u064a\u0641\u0629 \u062c\u062f\u064b\u0627","bad":"\u0636\u0639\u064a\u0641\u0629","good":"\u0645\u062a\u0648\u0633\u0637","strong":"\u0642\u0648\u064a\u0629","mismatch":"\u063a\u064a\u0631 \u0645\u062a\u0637\u0627\u0628\u0642\u0629"};
/* ]]> */
</script>
<script type="text/javascript" id="password-strength-meter-js-translations">
/* <![CDATA[ */
( function( domain, translations ) {
	var localeData = translations.locale_data[ domain ] || translations.locale_data.messages;
	localeData[""].domain = domain;
	wp.i18n.setLocaleData( localeData, domain );
} )( "default", {"translation-revision-date":"2024-02-13 12:49:38+0000","generator":"GlotPress\/4.0.0-beta.2","domain":"messages","locale_data":{"messages":{"":{"domain":"messages","plural-forms":"nplurals=6; plural=(n == 0) ? 0 : ((n == 1) ? 1 : ((n == 2) ? 2 : ((n % 100 >= 3 && n % 100 <= 10) ? 3 : ((n % 100 >= 11 && n % 100 <= 99) ? 4 : 5))));","lang":"ar"},"%1$s is deprecated since version %2$s! Use %3$s instead. Please consider writing more inclusive code.":["\u062a\u0645 \u0625\u064a\u0642\u0627\u0641 %1$s \u0645\u0646\u0630 \u0627\u0644\u0625\u0635\u062f\u0627\u0631 %2$s! \u0627\u0633\u062a\u062e\u062f\u0645 %3$s \u0628\u062f\u0644\u0627\u064b \u0645\u0646 \u0630\u0644\u0643. \u064a\u0631\u062c\u0649 \u0627\u0644\u0646\u0638\u0631 \u0641\u064a \u0643\u062a\u0627\u0628\u0629 \u0643\u0648\u062f \u0623\u0643\u062b\u0631 \u0634\u0645\u0648\u0644\u0627\u064b."]}},"comment":{"reference":"wp-admin\/js\/password-strength-meter.js"}} );
/* ]]> */
</script>
<script type="text/javascript" src="https://caawn.org.sa/wp-admin/js/password-strength-meter.min.js?ver=6.8.3" id="password-strength-meter-js"></script>
<script type="text/javascript" src="https://caawn.org.sa/wp-includes/js/underscore.min.js?ver=1.13.7" id="underscore-js"></script>
<script type="text/javascript" id="wp-util-js-extra">
/* <![CDATA[ */
var _wpUtilSettings = {"ajax":{"url":"\/wp-admin\/admin-ajax.php"}};
/* ]]> */
</script>
<script type="text/javascript" src="https://caawn.org.sa/wp-includes/js/wp-util.min.js?ver=6.8.3" id="wp-util-js"></script>
<script type="text/javascript" src="https://caawn.org.sa/wp-includes/js/dist/dom-ready.min.js?ver=f77871ff7694fffea381" id="wp-dom-ready-js"></script>
<script type="text/javascript" id="wp-a11y-js-translations">
/* <![CDATA[ */
( function( domain, translations ) {
	var localeData = translations.locale_data[ domain ] || translations.locale_data.messages;
	localeData[""].domain = domain;
	wp.i18n.setLocaleData( localeData, domain );
} )( "default", {"translation-revision-date":"2024-02-13 12:47:46+0000","generator":"GlotPress\/4.0.0-beta.2","domain":"messages","locale_data":{"messages":{"":{"domain":"messages","plural-forms":"nplurals=6; plural=(n == 0) ? 0 : ((n == 1) ? 1 : ((n == 2) ? 2 : ((n % 100 >= 3 && n % 100 <= 10) ? 3 : ((n % 100 >= 11 && n % 100 <= 99) ? 4 : 5))));","lang":"ar"},"Notifications":["\u0627\u0644\u0625\u0634\u0639\u0627\u0631\u0627\u062a"]}},"comment":{"reference":"wp-includes\/js\/dist\/a11y.js"}} );
/* ]]> */
</script>
<script type="text/javascript" src="https://caawn.org.sa/wp-includes/js/dist/a11y.min.js?ver=3156534cc54473497e14" id="wp-a11y-js"></script>
<script type="text/javascript" id="user-profile-js-extra">
/* <![CDATA[ */
var userProfileL10n = {"user_id":"0","nonce":"12f9e5a559"};
/* ]]> */
</script>
<script type="text/javascript" id="user-profile-js-translations">
/* <![CDATA[ */
( function( domain, translations ) {
	var localeData = translations.locale_data[ domain ] || translations.locale_data.messages;
	localeData[""].domain = domain;
	wp.i18n.setLocaleData( localeData, domain );
} )( "default", {"translation-revision-date":"2024-02-13 12:49:38+0000","generator":"GlotPress\/4.0.0-beta.2","domain":"messages","locale_data":{"messages":{"":{"domain":"messages","plural-forms":"nplurals=6; plural=(n == 0) ? 0 : ((n == 1) ? 1 : ((n == 2) ? 2 : ((n % 100 >= 3 && n % 100 <= 10) ? 3 : ((n % 100 >= 11 && n % 100 <= 99) ? 4 : 5))));","lang":"ar"},"Your new password has not been saved.":["\u0644\u0645 \u064a\u062a\u0645\u0651 \u062d\u0641\u0638 \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631 \u0627\u0644\u062c\u062f\u064a\u062f\u0629 \u0627\u0644\u062e\u0627\u0635\u0629 \u0628\u0643."],"Hide":["\u0625\u062e\u0641\u0627\u0621"],"Show":["\u0639\u0631\u0636"],"Confirm use of weak password":["\u062a\u0623\u0643\u064a\u062f \u0627\u0633\u062a\u062e\u062f\u0627\u0645 \u0643\u0644\u0645\u0629 \u0645\u0631\u0648\u0631 \u0636\u0639\u064a\u0641\u0629"],"Hide password":["\u0625\u062e\u0641\u0627\u0621 \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631"],"Show password":["\u0639\u0631\u0636 \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631"]}},"comment":{"reference":"wp-admin\/js\/user-profile.js"}} );
/* ]]> */
</script>
<script type="text/javascript" src="https://caawn.org.sa/wp-admin/js/user-profile.min.js?ver=6.8.3" id="user-profile-js"></script>
<!-- CAPTCHA added with CAPTCHA 4WP plugin. More information: https://captcha4wp.com -->			<script id="c4wp-inline-js" type="text/javascript">
				/* @v2-checkbox-js:start */
				var c4wp_onloadCallback = function() {
					for ( var i = 0; i < document.forms.length; i++ ) {
						let form = document.forms[i];

						let captcha_div = form.querySelector( '.c4wp_captcha_field_div:not(.rendered)' );
						let foundSubmitBtn = null;
												
						if ( null === captcha_div ) {
							continue;	
						}					

						captcha_div.innerHTML = '';

						if ( null != foundSubmitBtn ) {
							foundSubmitBtn.classList.add( 'disabled' );
							foundSubmitBtn.setAttribute( 'disabled', 'disabled' );

							if ( form.classList.contains( 'woocommerce-checkout' ) ) {
								setTimeout( function(){ 
									foundSubmitBtn = form.querySelector( '#place_order' );
									foundSubmitBtn.classList.add( 'disabled' );
									foundSubmitBtn.setAttribute( 'disabled', 'disabled' );
								}, 2500 );
							}
						}

						( function( form ) {
							var c4wp_captcha = grecaptcha.render( captcha_div,{
								'sitekey' : '6Lc3rL8rAAAAAP6LLkVNnav47DG_5Juj2UKIpr-D',
								'size'  : 'normal',
								'theme' : 'light',
								'expired-callback' : function(){
									grecaptcha.reset( c4wp_captcha );
								},
								'callback' : function( token ){
									if ( null != foundSubmitBtn ) {
										foundSubmitBtn.classList.remove( 'disabled' );
										foundSubmitBtn.removeAttribute( 'disabled' );
									}
									if ( typeof jQuery !== 'undefined' && jQuery( 'input[id*="c4wp-wc-checkout"]' ).length ) {
										let input = document.querySelector('input[id*="c4wp-wc-checkout"]'); 
										let lastValue = input.value;
										input.value = token;
										let event = new Event('input', { bubbles: true });
										event.simulated = true;
										let tracker = input._valueTracker;
										if (tracker) {
											tracker.setValue( lastValue );
										}
										input.dispatchEvent(event)
									}
								}
							});
							captcha_div.classList.add( 'rendered' );
													})(form);
					}
				};

				window.addEventListener("load", (event) => {
					if ( typeof jQuery !== 'undefined' && jQuery( 'input[id*="c4wp-wc-checkout"]' ).length ) {
						var element = document.createElement('div');
						var html = '<div class="c4wp_captcha_field" style="margin-bottom: 10px" data-nonce="e34621ff99" data-c4wp-use-ajax="true" data-c4wp-v2-site-key=""><div id="c4wp_captcha_field_0" class="c4wp_captcha_field_div"></div></div>';
						element.innerHTML = html;
						jQuery( '[class*="c4wp-wc-checkout"]' ).append( element );
						jQuery( '[class*="c4wp-wc-checkout"]' ).find('*').off();
						c4wp_onloadCallback();
					}
				});
				/* @v2-checkbox-js:end */
			</script>
						
			<script id="c4wp-recaptcha-js" src="https://www.google.com/recaptcha/api.js?onload=c4wp_onloadCallback&#038;render=explicit&#038;hl=ar"
				async defer>
			</script>

			<!-- / CAPTCHA by CAPTCHA 4WP plugin -->				<style type="text/css" id="c4wp-checkout-css">
					.woocommerce-checkout .c4wp_captcha_field {
						margin-bottom: 10px;
						margin-top: 15px;
						position: relative;
						display: inline-block;
					}
				</style>
							<style type="text/css" id="c4wp-v3-lp-form-css">
				.login #login, .login #lostpasswordform {
					min-width: 350px !important;
				}
				.wpforms-field-c4wp iframe {
					width: 100% !important;
				}
			</style>
				</body>
	</html>
	